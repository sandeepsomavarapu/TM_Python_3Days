try:
    num=int(input("Enter Denominator for division : "))#0
    result = 12 /num #PVM
    print("Result is", result)#error code/risky code 
except ZeroDivisionError:  
    print("Don't Enter zero denominator")
except ValueError:
    print("enter only numbers ...")    
except Exception as e:
    print("Another error",e.__class__)    
finally:
    print("Execute always whether exception is raised or not handled or not")    
print("remaining 1000 lines of code")
#try except finally raise
#abnormal termination/system defined error messages
#normal termination/user friendly error messages




