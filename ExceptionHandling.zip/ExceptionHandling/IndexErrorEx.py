names=[12,21,43,1,55,32,65,21]
print(names[0])
print(names[9])
