emps={1:'sandeep',2:'naresh',3:'ritish',4:'kiran'}
print(emps[1])
print(emps[10])